﻿$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root
Write-Host ""
Write-Host "PET MY CAT - WINDOWS SETUP" -ForegroundColor Cyan
Write-Host "Checking source files in: $root"
$required = @("index.html", "css\style.css", "js\app.js")
foreach ($relative in $required) {
    $path = Join-Path $root $relative
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
        throw "Missing required source file: $relative"
    }
    if ((Get-Item -LiteralPath $path).Length -eq 0) {
        throw "Required source file is empty: $relative"
    }
    Write-Host "[OK] $relative" -ForegroundColor Green
}
$htmlPath = Join-Path $root "index.html"
$cssPath = Join-Path $root "css\style.css"
$jsPath = Join-Path $root "js\app.js"
$html = Get-Content -Raw -LiteralPath $htmlPath
$css = Get-Content -Raw -LiteralPath $cssPath
$js = Get-Content -Raw -LiteralPath $jsPath
if ($html -notmatch 'href=["'']css/style\.css["'']' -or $html -notmatch 'src=["'']js/app\.js["'']') {
    throw "index.html does not contain the expected CSS and JavaScript references."
}
$html = [regex]::Replace($html, '(?i)<link[^>]+href=["'']css/style\.css["''][^>]*>\s*', ("<style>`r`n" + $css + "`r`n</style>"))
$html = [regex]::Replace($html, '(?i)<script[^>]+src=["'']js/app\.js["''][^>]*>\s*</script>', ("<script>`r`n" + $js + "`r`n</script>"))
if ($html -match 'href=["'']css/style\.css["'']|src=["'']js/app\.js["'']') {
    throw "Could not embed the CSS and JavaScript files."
}
$outPath = Join-Path $root "Play.html"
Set-Content -LiteralPath $outPath -Value $html -Encoding UTF8
Write-Host "[OK] CSS embedded" -ForegroundColor Green
Write-Host "[OK] JavaScript embedded" -ForegroundColor Green
Write-Host "[OK] Created Play.html in the source folder" -ForegroundColor Green
Start-Process $outPath
