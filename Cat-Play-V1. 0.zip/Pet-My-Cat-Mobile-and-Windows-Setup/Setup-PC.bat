@echo off
setlocal
title Pet My Cat - Windows Setup
cd /d "%~dp0"
echo.
echo PET MY CAT - WINDOWS SETUP
echo Checking and building Play.html in:
echo %CD%
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Setup-PC.ps1"
if errorlevel 1 (
  echo.
  echo SETUP FAILED. Read the error above and ensure the ZIP was fully extracted.
  pause
  exit /b 1
)
echo.
echo Done. Play.html was created in this same folder and opened in your browser.
pause
endlocal
