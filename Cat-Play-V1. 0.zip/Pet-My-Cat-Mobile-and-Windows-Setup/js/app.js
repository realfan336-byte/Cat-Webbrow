(() => {
"use strict";
const cat=document.getElementById("cat"),scene=document.getElementById("scene");
const statusText=document.getElementById("status"),purrFill=document.getElementById("purrFill");
const percent=document.getElementById("percent"),hint=document.getElementById("hint");
let purrLevel=0,isPetting=false,petInterval=null,drainInterval=null;
function updateMeter(){purrLevel=Math.max(0,Math.min(100,purrLevel));purrFill.style.width=purrLevel+"%";percent.textContent=purrLevel+"%";}
function spawnHeart(event){
 const heart=document.createElement("span");heart.className="heart";
 heart.textContent=["❤️","💕","💖","💗"][Math.floor(Math.random()*4)];
 const r=scene.getBoundingClientRect();let x=scene.clientWidth/2,y=scene.clientHeight/2-45;
 if(event&&Number.isFinite(event.clientX)){x=event.clientX-r.left;y=event.clientY-r.top;}
 heart.style.left=(x+(Math.random()*34-17))+"px";heart.style.top=y+"px";scene.appendChild(heart);
 heart.addEventListener("animationend",()=>heart.remove(),{once:true});
}
function startPetting(event){
 if(isPetting){if(event)spawnHeart(event);return;}
 isPetting=true;clearInterval(drainInterval);drainInterval=null;
 cat.classList.add("purring");statusText.textContent="Purring... ❤️";hint.textContent="Your cat loves the attention!";
 spawnHeart(event);
 petInterval=setInterval(()=>{purrLevel=Math.min(100,purrLevel+4);updateMeter();if(Math.random()<.65)spawnHeart();statusText.textContent=purrLevel>=100?"Super Happy! 💖":"Purring... ❤️";},100);
}
function stopPetting(){
 if(!isPetting)return;
 isPetting=false;clearInterval(petInterval);petInterval=null;cat.classList.remove("purring");
 statusText.textContent=purrLevel>=80?"Happy! 😻":"Curious 🐱";hint.textContent="Pet your cat again for more happiness!";
 clearInterval(drainInterval);
 drainInterval=setInterval(()=>{if(isPetting){clearInterval(drainInterval);drainInterval=null;return;}
  if(purrLevel>0){purrLevel=Math.max(0,purrLevel-2);updateMeter();}
  else{clearInterval(drainInterval);drainInterval=null;statusText.textContent="Curious 🐱";hint.textContent="Tap or hold the cat to pet it!";}
 },100);
}
function resetCat(){isPetting=false;clearInterval(petInterval);clearInterval(drainInterval);petInterval=drainInterval=null;purrLevel=0;
 cat.classList.remove("purring");statusText.textContent="Curious 🐱";hint.textContent="Tap or hold the cat to pet it!";updateMeter();scene.querySelectorAll(".heart").forEach(h=>h.remove());}
cat.addEventListener("pointerdown",e=>{e.preventDefault();startPetting(e);});
document.addEventListener("pointerup",stopPetting);document.addEventListener("pointercancel",stopPetting);window.addEventListener("blur",stopPetting);
document.getElementById("petBtn").addEventListener("click",()=>startPetting());
document.getElementById("stopBtn").addEventListener("click",stopPetting);
document.getElementById("resetBtn").addEventListener("click",resetCat);
cat.addEventListener("keydown",e=>{if(e.key==="Enter"||e.key===" "){e.preventDefault();startPetting();}});
cat.addEventListener("keyup",e=>{if(e.key==="Enter"||e.key===" ")stopPetting();});
document.querySelectorAll(".swatch").forEach(b=>b.addEventListener("click",()=>document.documentElement.style.setProperty("--cat-color",b.dataset.color)));
setInterval(()=>{if(isPetting)return;cat.classList.add("blink");setTimeout(()=>cat.classList.remove("blink"),180);},3500);
updateMeter();
})();